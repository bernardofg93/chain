<div class="head-freight">
    <div class="text-home">
        <h1>Freight</h1>
        <h1>Forwarder</h1>
    </div>
</div>

<!-- Area box modes !-->
<div class="area-modes">
   <div class="grid-area-modes">
        <h1>Modes</h1>
        <div class="box-area-modes bx-1">
            <img src="<?=BASE_URL?>assets/img/forwarder/icon1.png" alt="">
            <a href="">AIR</a>
        </div>
        <div class="box-area-modes bx-2">
            <img src="<?=BASE_URL?>assets/img/forwarder/icon2.png" alt="">
            <a href="" id="btn-mult">MULTIMODAL(COMBINED)</a>
        </div>
        <div class="box-area-modes bx-3">
            <img src="<?=BASE_URL?>assets/img/forwarder/icon3.png" alt="">
            <a href="">OCEAN</a>
        </div>
    </div>
</div>

<?php require_once 'views/our_industries.php';








