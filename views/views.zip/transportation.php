<div class="header-transportation">
    <div class="txt-header">
        <h1>Transportation<h1>
    </div>
</div>

<div class="our-modes-transportation">
    <h1>Our Modes</h1>
    <div class="box-icons">
        <div class="box">
            <img src="<?=BASE_URL?>assets/img/transportation/p1.png" alt="">
            <a href="">TRUCKLOAD</a>
        </div>
        <div class="box">
            <img src="<?=BASE_URL?>assets/img/transportation/p2.png" alt="">
            <a href="">LESS THAN TRUCKLOAD</a>
        </div>
        <div class="box">
            <img src="<?=BASE_URL?>assets/img/transportation/p3.png" alt="">
            <a href="">INTERMODAL</a>
        </div>
    </div>
</div>

<?php require_once 'views/our_industries.php' ?>

