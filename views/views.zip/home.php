<div class="header-home">
    <div class="text-home">
        <h1>Efficient</h1>
        <h1><span>&</span></h1>
        <h1>Reliable Logistics Expertise</h1>
    </div>
</div>
<?php require_once 'views/layout/bar_contact.php'; ?>

<!-- area de iconos -->
<div class="container-icons-home">
    <div class="icon icon-1">
        <img src="<?=BASE_URL?>assets/img/truckload/truck2.png" alt="">
        <a href="<?=BASE_URL?>page/carriers">Carriers</a>
    </div>
    <div class="icon icon-2">
        <img src="<?=BASE_URL?>assets/img/truckload/man.png" alt="">
        <a href="<?=BASE_URL?>page/brokerage">Brokerage</a>
    </div>
    <div class="icon icon-3">
        <img src="<?=BASE_URL?>assets/img/home/ship.png" alt="">
        <a href="<?=BASE_URL?>page/freightforwarder">Freightforwarder</a>
    </div>
    <div class="icon icon-4">
        <img src="<?=BASE_URL?>assets/img/home/truck.png" alt="">
        <a href="<?=BASE_URL?>page/transportation">Transportation</a>
    </div>
    <div class="icon icon-5">
        <img src="<?=BASE_URL?>assets/img/home/usa.png" alt="">
        <a href="<?=BASE_URL?>page/inbondmovement">Inbondmovement</a>
    </div>
    <div class="icon icon-6">
        <img src="<?=BASE_URL?>assets/img/home/box.png" alt="">
        <a href="<?=BASE_URL?>page/section321">Section 321</a>
    </div>
    <div class="icon icon-7">
        <img src="<?=BASE_URL?>assets/img/home/continents.png" alt="">
        <a href="<?=BASE_URL?>page/shipperexports">Shipperexports</a>
    </div>
    <div class="icon icon-8"> 
         <img src="<?=BASE_URL?>assets/img/home/call.png" alt="">
         <a href="<?=BASE_URL?>page/contact">Contact</a>
    </div>
</div>

<!--area abaout us what akes us diferent? -->
<div class="container-about-us">
    <div class="cont-about-us bx-cont-about-us">
        <div class="about box">
            <img src="<?=BASE_URL?>assets/img/home/icon-abaut-us-home.png" alt="">
            <a href="<?=BASE_URL?>page/aboutblchain" class="btn-about us">About Us</a>
        </div>
    </div>
    <div class="cont-different bx-cont-about-us">
        <div class="different box">
            <div class="txt-diferent">
                <h1 id="title">What makes us</h1>
                <h1>DIFFERENT?</h1>  
            </div>
            <div class="bx-txt-diff">
                <p> 
                    We give a unique value to our clients and vendors network , 
                    no matter their needs, we provide the best solutions for their supply chain ,
                    making the global trade community more efficient and reliable.
                </p>
                <p>
                    With BLCHAIN as your Partner you have access of our full range of expertise of Customs Brokerage 
                    ,Freight Forwarding, Logistics , Transportation and Trade Consulting services to build the best
                    solutions that work for your business , more precisely for Importers and Exporters alike 
                    .BLCHAIN is the best choice for cost-effective and compliant trade solutions. We are motivated 
                    to help you grow your business and stay highly compliant in the process.
                </p>
                <a href="<?=BASE_URL?>page/aboutblchain" class="btn-about btn-different">Know more</a>
            </div>
        </div>
    </div>
</div>

<!-- Area expertise -->
<div class="container-expertise">
    <div class="txt-1 tbox">
        <h1>Expertise</h1>
        <p>BLOCKCHAIN LOGISTICS is a Customhouse Broker, Freight Forwarder and logistics provider located 
            in San Diego USA – Tijuana Mexico, a dominant commercial region in the USA and Mexico 
            and the main gateway to international trade between California and Mexico. We provide a 
            highly integrated supply chain network solutions  
            that links producers and consumers through multiple transportation modes, including 
            air and express delivery services, freight rail, maritime transport, and truck transport. 
            To serve customers efficiently,  we are committed to provide our unique reliable service,  
            connecting logistics and transportation solutions to ensure the coordination of goods movement 
            from origin to end user through each supply chain network segment. We serve manufacturers, 
            importers, retailer, distributors, that operate in North America moving their freights to 
            reach their destination.
        </p>
        <p>
            Take your industry lead with our Customs brokerage and freight forwarder services to ensure 
            accurate customs compliance and timely clearance of your goods.
        </p>
    </div>
    <div class="txt-2 tbox">
       <h3>U.S CUSTOMHOUSE BROKER SERVICES</h3> 
        <p>
            You can't afford delays in your supply chain — let BLCHAIN Trade
            Networks help speed your shipments through Customs quickly and in compliance at the best price possible. 
            Fastest Customs processing and release times at the border.
       </p>
       <h3>SECTION 321 U.S.A IMPORT</h3> 
        <p>
            !We make you conquer the E-Commerce! DAILY IMPORT ARTICLES BY ONE PERSON 
            into The US WITH A VALUE NOT EXCEEDING  $800 DOLLARS, !FREE OF DUTIES! 
       </p>
       <h3>CROSS BORDER SOLUTIONS AND E-MANIFEST</h3> 
        <p>
            We can move it all. You can't afford delays in your supply chain 
            — let BLCHAIN Trade Networks help speed your shipments quickly and
             in compliance and at the best price possible. 
       </p>
       <h3>CARRIER SERVICES (INTRA USA/ MEXICO)</h3> 
        <p>
            when it comes to moving through customs without delays, 
            there is no substitute for fastest carrier at the border. 
       </p>
       <h3>BONDED CARRIER (IN-BOND MOVEMENT “IN TRANSIT” THROUGH THE US)</h3> 
        <p>
            movement of merchandise through the United States without payment 
            of duty and taxes prior to entry into domestic or foreign commerce.
       </p>
    </div>
    <div class="txt-3 tbox">
       <h3>WAREHOUSE SYSTEM AND DISTRIBUTIONS SERVICES</h3> 
        <p>
            ensure your merchandise is received and distributed in the most convenient,
             cost-effective way possible.
       </p>
       <h3>FREIGHT FORWARDER & LOGISTICS SERVICES</h3> 
        <p>
            whether you are shipping air, ocean, or ground. 
            When it comes to moving through customs without delays, 
            there is no substitute for experience, reliability and cost effectiveness.
       </p>
       <h3>US EXPORT AES SOLUTIONS for ELECTRONIC EXPORT INFORMATION FILING(EEI) </h3> 
        <p>
            Get ready to Export! and have the amazing 
            opportunity to expand your business internationally.
       </p>
       <h3>IMPORTATION into MEXICO </h3> 
        <p>
            (Comercializadora) Do not take risk when importing into Mexico or Exporting from Mexico, 
            Blockchain Logistics LLC  provides you with the services of an Importer/Comercializadora 
            with extensive experience in Mexican Customs Clearance and Foreign Trade. 
       </p>
       <h3>GLOBAL TRADE ADVISORY AND CONSULTING SERVICES </h3> 
        <p>
             will help you to quickly recognize, assess, and adapt to new import/export processes 
             to minimize risk and gain a competitive trade advantage. 
       </p>
    </div>
</div>  

<!-- Area Twitter -->
<div class="container-twiter">
    <h1>News & Articles</h1>
    <div class="container-twitter">
        <a class="twitter-timeline" href="https://twitter.com/CBPTradeGov?ref_src=twsrc%5Etfw">Tweets by CBPTradeGov</a> 
        <div class="twits">
            <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script> 
        </div>
    </div>
</div>
