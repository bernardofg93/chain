<div class="ocean-offerings">
    <h1 id="title-box-offerings">Ocean Offerings</h1>
    <div class="grid-offerings">
        <div class="box-icon-offerings">
            <div class="box-img-offering">
                <img src="<?=BASE_URL?>assets/img/ocean/boxes.png" alt="" id="boxes">
            </div>
            <h1>Consolidated</h1>
        </div>
        <div class="box-icon-offerings">
            <img src="<?=BASE_URL?>assets/img/ocean/wheater.png" alt="">
            <h1>Temperature</h1>
            <h1>Controlled</h1>
        </div>
        <div class="box-icon-offerings">
            <div class="box-img-offering">
                <img src="<?=BASE_URL?>assets/img/ocean/truck.png" alt="">
                <img src="<?=BASE_URL?>assets/img/air/airplane.png" alt="">
                <img src="<?=BASE_URL?>assets/img/ocean/ship.png" alt="">
            </div>
            <h1>Project Freight</h1>
            <h1>Container</h1>
        </div>
    </div>
    <a href="">Request your freight quote</a>
</div>