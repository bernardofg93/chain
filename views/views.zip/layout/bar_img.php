<div class="bar-blue bar-img">
    <h1>Need to ship something?</h1>
    <h1><i class="fas fa-phone-volume"></i>+1 (619)- 721 -1973 +1 (619)- 395-5116</h1>
    <a href="">Request your Freight Quote</a>
</div>
