<!-- Area box solutions !-->
<div class="our-solutions">
        <h1>Our Solutions</h1>
    <div class="box-icons">
            <div class="box-our">
                    <a href="">
                        <img src="<?=BASE_URL?>assets/img/transportation/a1.png" alt="" id="icon-sm">
                    </a>
            </div>
        <div class="box-our">
                <a href="">
                    <img src="<?=BASE_URL?>assets/img/transportation/a2.png" alt="">
                </a>
        </div>
        <div class="box-our">
                <a href="">
                    <img src="<?=BASE_URL?>assets/img/transportation/a3.png" alt="" id="icon-sm">
                </a>
        </div>
    </div>
    <a href="" class="supply-btn">SUPPLY CHAIN PLANNING & MANAGEMENT</a>
</div>

<!-- Icons our industrys !-->
<div class="bar-icons">
    <h1>Our Industries</h1>
<div class="cont-grid-industries">
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic1.png" alt="">
            <p>Consumer Goods</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic2.png" alt="">
            <p>Energy &</p>
            <p>Infrastructure</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic3.png" alt="">
            <p>Food & Beverages</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic4.png" alt="">
            <p>Industrial Goods</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic5.png" alt="">
            <p>Paper & Packaging</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic6.png" alt="">
            <p>Pharmaceuticals and</p>
            <p>Health care</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic7.png" alt="">
            <p>Retailers</p>
        </div>
        <div class="box-bar">
            <img src="<?=BASE_URL?>assets/img/industries/ic8.png" alt="">
            <p>Technology</p>
        </div>
   </div> 
</div>
